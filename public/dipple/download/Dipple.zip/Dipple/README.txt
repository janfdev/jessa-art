Dipple
A soft, chunky display font by Jessa Wolfe.

Two styles: Dipple Rough (inky, hand-made edges) and Dipple Smooth (clean edges).
Includes A-Z, a-z, 0-9, punctuation, and a set of Dipple stars: ✦ ★ ✶ ✷ ✸ ✧

Install on a Mac: double-click Dipple-Rough.otf and Dipple-Smooth.otf, then Install.
Install on Windows: right-click each .otf, then Install.
For websites: use the .woff2 files.

Made by Jessa ✦ jessa.art
